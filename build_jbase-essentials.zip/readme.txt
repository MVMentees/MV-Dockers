LOGIN:
 In order to take quizzes and receive a badge for completion
	https://learn.rocketsoftware.com

DOWNLOAD the newest UniData Personal Edition:
        https://www.rocketsoftware.com/en-us/products/multivalue/jbase/linux-free-trial

You can now either use docker compose with the existing jbase-essentials.yaml or add the lines to an existing yaml

Using yaml
===================================
CHECK:   Check the contents are correct for you;  ports are for remote access and telnet

COMBINE: You could also combine these lines with an existing yaml to compose multiple dockers in one compose yaml

RUN:     If you use the individual included yaml then run as detailed in the yaml.  If you combined it into an
         existing yaml you would run that.
     

Using docker without compose yaml
===================================
BUILD: 
 Build the docker image you just downloaded
	Unzip the files into a directory like dockers/jbase-essentials
        Add the JBPE version you downloaded to that same directory
	Run	docker build -t jbase-essentials .

RUN WITH SAVED PROGRESS:
 This is preferred if you want to KEEP your tutorial accounts separate from the docker. Allowing you to
 save your work as you progress through the tutorial.

 Linux:         docker run -it -p2223:23 --rm -v /savedUV:/mystuff:z jbase-essentials:latest
 Windows:       docker run -it --rm -v C:\savedUV:/mystuff:z jbase-essentials:latest

 Note: The directory/folder specification before the colon must exist and can be any preferably empty one
       in place of the /savedUV or C:\savedUV.

RUN WITHOUT SAVED PROGRESS:
 If you do not want or cannot save progress, you can run the docker without external volume.

 Linux:         docker run -it -p2223:23 --rm jbase-essentials:latest
 Windows:       docker run -it --rm jbase-essentials:latest

Note:  The -p2223:23 allows telnet access to the docker on host port 2223.
       Add -p32438:20002 to allow for MVVS/VSCode access.
       Ports 2223 and 32348 are arbitrary and you can use whatever is available.
